# -*- coding: utf-8 -*-
from pathlib import Path
from hashlib import sha256
import json,stat,zipfile
D=Path(__file__).resolve().parent;R=D.parents[1];H=R/'work/C08_author_effective_r1_delivery_handoff.json';raw=H.read_bytes();assert sha256(raw).hexdigest()=='0a280e4df53a326265cd7fe50debe89f4028bf2e3a1e6fd8dd45ff1486c5acc6';h=json.loads(raw);P=Path(h['directory']);mf=(P/'DELIVERY_MANIFEST_r1.json').read_bytes();fr=(P/'DELIVERY_FREEZE_r1.json').read_bytes();assert sha256(mf).hexdigest()=='5d5016b696bb55bd101b5592bd32cf5fedbf3b08b610881961bbd064f916add4';assert sha256(fr).hexdigest()=='fe444a07f44bd0eec1c9868fb6e139a27dffdb2145e2bde466695350cc4e9003';assert json.loads(fr)['manifest_sha256']==sha256(mf).hexdigest();files=json.loads(mf)['files'];assert len(files)==283
actual={str(p.relative_to(P))for p in P.rglob('*')if p.is_file()and not p.is_relative_to(P/'prepared_runtime')};assert actual==set(files)|{'DELIVERY_MANIFEST_r1.json','DELIVERY_FREEZE_r1.json'}and len(actual)==285
old=json.loads((D/'prior/final_frozen_delivery_target_acknowledged.json').read_text())['all_permanent_files'];verified=[];total=0
for rel,v in files.items():
 p=P/rel;assert not p.is_symlink();digest=sha256();size=0
 with p.open('rb')as f:
  for b in iter(lambda:f.read(8*1024*1024),b''):digest.update(b);size+=len(b)
 assert(size,digest.hexdigest())==(v['bytes'],v['sha256']),rel
 st=p.stat()
 if rel in old:
  o=old[rel];assert(st.st_dev,st.st_ino,st.st_mode,size,digest.hexdigest())==(o['device'],o['inode'],o['mode'],o['bytes'],o['sha256']),rel
 total+=size;verified.append(dict(relative=rel,bytes=size,sha256=digest.hexdigest(),mode=st.st_mode,device=st.st_dev,inode=st.st_ino))
assert total==5528208609
for rel,v in h['new9_file_pins'].items():assert files[rel]==v
C=json.loads((P/'research_catalog_effective_r1.json').read_text());source=json.loads((D/'actual/all95_current_policy_original_document_pins_pre_delivery.json').read_text());refs=[]
for m in source['rows']:
 for r in [m['current_policy'],*m['original_actual_documents']]:
  key=C['original_source_path_to_relative_key'][r['path']];meta=C['files'][key];assert(meta['bytes'],meta['sha256'])==(r['bytes'],r['sha256']);assert meta['sha256']in C['objects'];refs.append(dict(component=m['component'],key=key,sha256=meta['sha256']))
assert len(refs)==95+207
assert C['files'][C['current_navigation_key']]['sha256']=='4f99a5e188deb71e682afa3ba3d8f096fedf5899734705f1f3542e841254aaea'
assert C['files'][C['current_root_scope_acceptance_key']]['sha256']=='187c9e4aaa1f8ab7480861944364c3be513a94a9e95a6b388068e5d88684d8b4'
assert C['files']['work/rev622_C03_original_full_acceptance/acceptance_decision.json']['sha256']=='d77bca18062e4564ce41a106563c71c685655e473d517d6907abdc6613a3027b'
precision=(P/'历史操作回执_读取精度说明.json').read_bytes();assert sha256(precision).hexdigest()=='33f61c584073ea130eb1d293a2c42934b9c21dd3a1a353cdb640bf367e9131e0'
correction=json.loads((P/'资料补收与当前生效说明_r1.json').read_text())
with zipfile.ZipFile(P/'交付验证证据_C08_r1.zip')as z:
 assert set(z.namelist())=={m['member']for m in correction['evidence_members']}
 for m in correction['evidence_members']:
  b=z.read(m['member']);assert(len(b),sha256(b).hexdigest())==(m['bytes'],m['sha256'])
report=dict(all_passed=True,permanent_payload_files283=True,permanent_total_files285=True,payload_bytes=total,original272_payload_exact_SHA_size_mode_inode_unchanged=True,original2_freeze_files_exact_in_combo_manifest=True,new9_material_files_plus2_current_freeze=True,runtime_native_entry_worker_guard_runtimecatalog_all_unchanged_prefix_reusable=True,current95policy_and207_originaldoc_exact_package_aliases=refs,current623_and622_exact=True,r1_evidence25_members_all_bytes_match=True,two_history_limits_and_operational_receipt_precision_physically_disclosed=True,no_new_math_or_self_adoption=True,package=str(P),current_manifest=dict(bytes=len(mf),sha256=sha256(mf).hexdigest()),current_freeze=dict(bytes=len(fr),sha256=sha256(fr).hexdigest()),all_permanent_payloads=verified)
(D/'actual/final_r1_285_permanent_fullSHA_302_currentdoc_aliases.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items()if k not in ['all_permanent_payloads','current95policy_and207_originaldoc_exact_package_aliases']},ensure_ascii=False,indent=2),flush=True)
