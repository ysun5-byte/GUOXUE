# -*- coding: utf-8 -*-
from pathlib import Path
from hashlib import sha256
import json,zipfile,gzip,ast,tempfile,re
D=Path(__file__).resolve().parent;OLD=D.parents[1];P=Path(json.loads((OLD/'work/C08_runtime_integration_after612/candidate_location.json').read_text())['path'])
docs=json.loads((P/'运行整合层_当前有效20个算法解释_r1.json').read_text());old=json.loads((P/'运行整合层_20个算法解释.json').read_text());oldby={r['id']:r for r in old['functions']}
assert len(docs['functions'])==20 and docs['total_physical_named_definitions22_including_superseded_reader'] is True
physical=sum(sum(isinstance(n,ast.FunctionDef) for n in ast.walk(ast.parse((P/f).read_bytes()))) for f in ['delivery_common.py','v1_entry.py','native_worker.py','prepare_runtime.py','research_files.py','research_files_effective_r1.py']);assert physical==22
assert (P/'research_files_effective_r1.py').read_text().replace('research_catalog_effective_r1.json','research_catalog.json').replace('4fb5143e6113338e5f97660f1dea5f8b462b4c821f13c4b5130d389f3c8e2602',sha256((P/'research_catalog.json').read_bytes()).hexdigest())==(P/'research_files.py').read_text()
with zipfile.ZipFile(P/'交付验证证据_C08_r1.zip')as z:
 prefix='C08_runtime_integration_after612/';builder=z.read(prefix+'normalize95_and_stage_source_r1.py');io=json.loads(gzip.decompress(z.read(prefix+'actual_effective_r1_reader_IO/first_complete_actual_r1_reader_IO.json.gz')));capture=z.read(prefix+'capture_effective_r1_reader_IO.py').decode()
 node=next(n for n in ast.parse(builder).body if isinstance(n,ast.FunctionDef)and n.name=='normalize')
 assert sha256(ast.dump(node,include_attributes=False).encode()).hexdigest()=='8d5cd29c8aac5ceba11524ae7e779baf5a9ae931ece02da8b4d18293c813cced'
 for i in range(2):
  records=json.loads(gzip.decompress(z.read(prefix+f'actual_effective_r1_reader_IO/{i}.function_IO.json.gz')));stdout=gzip.decompress(z.read(prefix+f'actual_effective_r1_reader_IO/{i}.stdout.gz'));f=records['fetch'];b=bytes.fromhex(f['return_event_value']['hex']);assert b==stdout and len(b)==f['return_event_value']['bytes']and sha256(b).hexdigest()==f['return_event_value']['sha256'];assert records['main']['input']['argv']==['show',f['input']['key']]and records['main']['return_event_value']==0
  assert records['main']['module_source_sha256']==f['module_source_sha256']==sha256((P/'research_files_effective_r1.py').read_bytes()).hexdigest()
  # Raw original bytes in the actual function pair are independently stored too.
  C=json.loads((P/'research_catalog_effective_r1.json').read_text())if i==0 else C;meta=C['files'][f['input']['key']];assert (len(b),sha256(b).hexdigest())==(meta['bytes'],meta['sha256'])
  obj=C['objects'][meta['sha256']]
  with zipfile.ZipFile(P/obj['volume_relative_path'])as volume:assert volume.read(obj['member'])==b
 assert 'sys.setprofile' in capture and "event=='return'" in capture
for r in docs['functions']:
 raw=(P/r['path']).read_bytes();tree=ast.parse(raw);n=next(n for n in ast.walk(tree)if isinstance(n,ast.FunctionDef)and n.lineno==r['line'])
 assert sha256(raw).hexdigest()==r['source_sha256'];assert sha256(ast.dump(n,include_attributes=False).encode()).hexdigest()==r['AST_sha256'];assert [a.arg for a in n.args.posonlyargs+n.args.args+n.args.kwonlyargs]==r['arguments']
 if r['path']!='research_files_effective_r1.py':assert r==oldby[r['id']]
 else:
  pair=io[n.name];assert pair['line']==n.lineno and pair['module_source_sha256']==r['source_sha256']and set(pair['input'])==set(r['arguments']);assert 'return_event_value'in pair
  assert 'fixed_data_catalog' in r['classification']and 'current_actual_IO_reference'in r;assert all(r['algorithm_contract'][k]for k in ['purpose','inputs','operations','outputs','preconditions_and_limits'])
# Builder normalization negative tests are fixed before calling the extracted
# actual normalizer. The producer does not itself parse arbitrary manifests.
H=sha256(b'').hexdigest();meta=dict(bytes=0,sha256=H);T=Path(tempfile.mkdtemp(prefix='C08 independent449 normalizer behavior '));spec=[
 ('zero_byte_file_valid',{'files':{'empty':meta}},True,None),('size_schema',{'files':{'empty':dict(size=0,sha256=H)}},True,None),('SHAonly',{'empty':H},True,None),('list_alias_same_name',{'files':[dict(path='x',relative_path='x',bytes=0,sha256=H)]},True,None),
 ('unknown_value',{'files':{'x':dict(length=0,sha256=H)}},False,'actual_bytes_or_size_manifest_required'),('empty_mapping',{'files':{}},False,'nonempty_supported_manifest_payload_required'),('empty_list',{'files':[]},False,'nonempty_supported_manifest_payload_required'),('wrong_container',{'files':None},False,'known_actual_manifest_container_required'),('escape',{'files':{'../x':meta}},False,'unique_relative_manifest_path_required'),('boolean_size',{'files':{'x':dict(bytes=False,sha256=H)}},False,'actual_bytes_or_size_manifest_required'),('conflicting_sizes',{'files':{'x':dict(bytes=0,size=1,sha256=H)}},False,'actual_bytes_or_size_manifest_required'),('ambiguous_list_path',{'files':[dict(path='x',relative_path='y',**meta)]},False,'unambiguous_manifest_record_path_required'),('duplicate_list_path',{'files':[dict(path='x',**meta),dict(path='x',**meta)]},False,'unique_relative_manifest_path_required'),('bad_SHA',{'files':{'x':dict(bytes=0,sha256=H.upper())}},False,'exact_SHA256_required')]
(D/'prior/08_r1_schema_behavior_before_actual_normalizer_calls.json').write_text(json.dumps([dict(id=i,input=v,accept=a,error_prefix=e)for i,v,a,e in spec],ensure_ascii=False,indent=2)+'\n')
namespace=dict(Path=Path,json=json,re=re);exec(compile(ast.Module(body=[node],type_ignores=[]),'<exact_frozen_r1_builder_normalizer>','exec'),namespace);rows=[]
for i,v,accept,prefix in spec:
 p=T/(i+'.json');p.write_text(json.dumps(v))
 try:out=namespace['normalize'](p)
 except ValueError as e:assert not accept and str(e).startswith(prefix);rows.append(dict(case=i,rejected=True,error=str(e).split(':')[0]))
 else:assert accept and len(out)==1 and out[0]['sha256']==H;rows.append(dict(case=i,accepted=True,normalized_rows=1))
runtime=json.loads((P/'runtime_catalog.json').read_text());oldhashes={k[7:]for k in C['unavailable_historical_SHA_keys']};runtime_hits=[]
for cid,component in runtime['components'].items():
 for rel,m in component['files'].items():
  if m['sha256']in oldhashes:runtime_hits.append([cid,rel])
assert not runtime_hits
report=dict(all_passed=True,current_named_algorithms20_physical22=True,original18_doc_AST_IO_literal_unchanged=True,reader2_only_exact_catalog_literal_and_moduleSHA_changes=True,reader2_real_actual_args_fullbytes_output_complete=True,not_module_heap_or_all_paths=True,actual_builder_source_AST_exact=True,new_independent_schema_cases=rows,unknown_and_empty_no_silent_zero=True,runtime96components_two_history_dependencies0=True,no_native_or_math_calls=True)
(D/'actual/r1_current20_contract_IO_and_schema_negative_audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps(report,ensure_ascii=False,indent=2))
