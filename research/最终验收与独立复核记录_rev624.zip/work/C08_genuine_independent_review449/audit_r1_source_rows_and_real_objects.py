# -*- coding: utf-8 -*-
"""Independent collection audit; no native BaZi or historical model rerun."""
from pathlib import Path
from hashlib import sha256
import json, zipfile, stat, sys, time, os
D=Path(__file__).resolve().parent; OLD=D.parents[1]
P=Path(json.loads((OLD/'work/C08_runtime_integration_after612/candidate_location.json').read_text())['path']).resolve()
expected=json.loads((D/'actual/all95_full_normalized_manifest_expected_rows_for_r1.json').read_text())
install=json.loads((OLD/'work/C08_runtime_integration_after612/r1_append_install_only_new_files.json').read_text())
pins=[]
for row in install['added']:
 raw=(P/row['relative']).read_bytes();assert(len(raw),sha256(raw).hexdigest())==(row['bytes'],row['sha256']);pins.append(row)
C=json.loads((P/'research_catalog_effective_r1.json').read_text());F=json.loads((P/'all95_normalized_original_manifest_rows_effective_r1.json').read_text())
allrows=F['expected_all_payload_path_records'];assert len(allrows)==49419
grouped={}
for r in allrows:
 key=(r['component'],r['relative']);assert key not in grouped;grouped[key]=r
assert len(expected['rows'])==len(F['rows'])==95
count=0;miss=[]
for method in expected['rows']:
 component=method['component'];mp=Path(method['actual_source_manifest']);base=mp.parent
 for e in method['normalized_payloads']:
  r=grouped[(component,e['relative'])];assert r['manifest']==str(mp)
  assert r['sha256']==e['expected_SHA256'];assert e['declared_bytes']is None or r['bytes']==e['declared_bytes']
  key=str((base/e['relative']).relative_to(OLD));meta=C['files'][key];assert(meta['bytes'],meta['sha256'])==(r['bytes'],r['sha256'])
  alias=C['files']['sha256:'+r['sha256']];assert(alias['bytes'],alias['sha256'])==(r['bytes'],r['sha256'])
  assert C['original_source_path_to_relative_key'][str(base/e['relative'])]==key
  assert C['objects'][r['sha256']]==r['storage']
  if not e['object_available_in_first_r0']:miss.append(r)
  count+=1
assert count==49419 and len(miss)==379
assert sum(r['component']=='rev359_true_transform_select_contract_repair' for r in miss)==135
assert len(C['entire_original501_layout'])==682
for layout in ['entire_original501_layout','current_reading_layout']:
 for alias,key in C[layout].items():assert key in C['files'] and C['files'][key]['sha256'] in C['objects']
oldkeys=['sha256:afaba15002c8a635157725509dfa70c55ef0c6d245957569c1e9315a5a142eb0','sha256:fc96b8778abb9424b8194272c190fcd33e35c355f12cf4ae0048010dcf5eec18']
for k in oldkeys:assert k in C['unavailable_historical_SHA_keys'] and k[7:]not in C['objects']
assert len(C['objects'])==21610
for key,v in C['files'].items():assert v['sha256']in C['objects'],key
# All expected tables are now in memory. Real package entity reads below must not
# fall back to the original workspace. This is a Python filesystem audit guard.
denials=[]
def audit(event,args):
 if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
  p=Path(os.fsdecode(args[0])).absolute()
  if p.is_relative_to(OLD):denials.append(str(p));raise RuntimeError('original_workspace_read_denied')
sys.addaudithook(audit)
zips={};verified=[];total=0;start=time.monotonic()
for i,(h,obj)in enumerate(C['objects'].items(),1):
 relative=obj['volume_relative_path'];assert not Path(relative).is_absolute()and'..'not in Path(relative).parts
 p=(P/relative).resolve();assert p.is_relative_to(P)
 if relative not in zips:zips[relative]=zipfile.ZipFile(p)
 z=zips[relative];info=z.getinfo(obj['member']);assert not info.is_dir()and not stat.S_ISLNK(info.external_attr>>16)
 digest=sha256();size=0
 with z.open(info)as f:
  while True:
   b=f.read(1024*1024)
   if not b:break
   digest.update(b);size+=len(b)
 assert (size,digest.hexdigest())==(obj['bytes'],h),(h,size,obj)
 total+=size;verified.append(dict(sha256=h,bytes=size,volume=relative,member=obj['member']))
 if i%2000==0:print('independent actual source objects',i,flush=True)
for z in zips.values():z.close()
assert not denials
report=dict(status='all95_exact49419_paths_aliases_and21610_real_objects_SHA_pass',all95_nonempty=True,expected_before_r1=True,normalized_path_rows49419=True,first_missing379_restored=True,new_rev359135_not_covered_by_history_exception=True,all_original501_682_reading_aliases_present=True,current_reading_aliases=len(C['current_reading_layout']),actual_unique_objects=len(verified),actual_uncompressed_object_bytes=total,old_workspace_read_attempts0=True,two_old_navigation_expected_raw_SHA_still_unavailable=True,no_native_math_calls=True,package=str(P),r1_four_exact_pins=pins,elapsed_seconds=time.monotonic()-start,verified_objects=verified)
# Writing the result is outside the audited old root via a pre-opened handle.
out=os.environ['C08_REVIEW449_EXTERNAL_RESULT'];Path(out).write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items()if k not in ['verified_objects','r1_four_exact_pins']},ensure_ascii=False),flush=True)
