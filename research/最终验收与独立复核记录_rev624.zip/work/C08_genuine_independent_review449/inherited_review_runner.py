# -*- coding: utf-8 -*-
"""Reviewer harness only. Actual denials inherited by Python native children."""
from pathlib import Path
import sys,os,json,subprocess,runpy,atexit,hashlib
cfg=json.loads(Path(os.environ['C08_REVIEW449_GUARD_CONFIG']).read_text());P=Path(cfg['package']).resolve();OLD=Path(cfg['old_project']).resolve();SELF=Path(__file__).resolve();mode=sys.argv[1];LOG=os.open(cfg['audit_log'],os.O_WRONLY|os.O_CREAT|os.O_APPEND,0o600)
counts=dict(old_read=0,old_scan=0,old_exec=0,package_write=0);wrapped=0;fault_reads=0;cache_writes=0;blocked=None;probe=OLD/'work/rev415_Ren_follow_qi_metal_water/qi.py';seed=probe.read_bytes()if mode=='negative_old_exec'else None
preparing=mode=='script'and Path(sys.argv[2]).resolve()==P/'prepare_runtime.py'and cfg.get('allow_cache_preparation',False)
def under(v,base):
 if not isinstance(v,(str,bytes,os.PathLike)):return False
 try:
  n=os.path.abspath(os.fsdecode(v));n='/private'+n if n.startswith('/var/')else n;return Path(n).is_relative_to(base)
 except(ValueError,TypeError):return False
def deny(key,message):
 global blocked
 counts[key]+=1;blocked=message;raise RuntimeError(message)
def package_mutation(path):
 global cache_writes
 if under(path,P):
  if preparing and under(path,P/'prepared_runtime'):cache_writes+=1
  else:deny('package_write','actual_package_write_blocked')
def audit(event,args):
 if event=='open':
  p,m,f=args
  if under(p,OLD):deny('old_read','actual_old_project_read_blocked')
  write=isinstance(m,str)and any(s in m for s in'wa+')or isinstance(f,int)and bool(f&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND))
  if write:package_mutation(p)
 if event in('os.scandir','os.listdir')and under(args[0],OLD):deny('old_scan','actual_old_project_scan_blocked')
 if event=='exec'and not str(args[0].co_filename).startswith('<')and under(args[0].co_filename,OLD):deny('old_exec','actual_old_project_execution_blocked')
 if event=='subprocess.Popen'and under(args[0],OLD):deny('old_exec','actual_old_project_subprocess_executable_blocked')
 if event=='sqlite3.connect'and under(args[0],OLD):deny('old_read','actual_old_project_sqlite_read_blocked')
 if event=='ctypes.dlopen'and args and under(args[0],OLD):deny('old_exec','actual_old_project_sharedcode_load_blocked')
 if event in('os.remove','os.rmdir','os.mkdir','os.chmod','os.truncate'):package_mutation(args[0])
 if event in('os.rename','os.replace','os.link'):
  # Linking an already checked immutable blob is allowed only in the explicit
  # preparation child and only at its new cache target; source remains read.
  for p in args[:2]:
   if under(p,OLD):deny('old_exec','old_project_mutation_or_link_blocked')
  package_mutation(args[1]);
  if event in('os.rename','os.replace'):package_mutation(args[0])
original_Popen=subprocess.Popen
def guarded_Popen(command,*args,**kwargs):
 global wrapped
 if isinstance(command,(list,tuple))and command and str(command[0]).split('/')[-1].lower().startswith('python'):
  values=list(command);i=1;isolated=False
  while i<len(values)and isinstance(values[i],str)and values[i].startswith('-'):
   isolated|=values[i]=='-I'
   if values[i]in('-c','-m'):raise RuntimeError('unregistered_python_launch_style_in_readonly_test')
   i+=1
  if i>=len(values):raise RuntimeError('Python_script_required_in_readonly_test')
  script=values[i]
  if under(script,OLD):deny('old_exec','actual_old_project_subprocess_execution_blocked')
  if not under(script,P):raise RuntimeError('unexpected_native_python_script_outside_current_package')
  command=[sys.executable,'-I','-B',str(SELF),'script',str(script),json.dumps(values[i+1:]),'1'if isolated else'0'];wrapped+=1;env=dict(os.environ if kwargs.get('env')is None else kwargs['env']);env['C08_REVIEW449_GUARD_CONFIG']=os.environ['C08_REVIEW449_GUARD_CONFIG'];kwargs['env']=env
 return original_Popen(command,*args,**kwargs)
subprocess.Popen=guarded_Popen
original_read=Path.read_bytes
def reader(self):
 global fault_reads
 raw=original_read(self)
 if cfg.get('fault_path')and self.resolve()==Path(cfg['fault_path']).resolve():fault_reads+=1;return raw+b'\nindependent449-controlled-actual-read-byte-fault'
 return raw
if cfg.get('fault_path'):Path.read_bytes=reader
sys.addaudithook(audit)
def finish():
 row=dict(pid=os.getpid(),ppid=os.getppid(),mode=mode,counts=counts,wrapped_python_children=wrapped,blocked=blocked,controlled_read_faults=fault_reads,explicit_prepare_child=preparing,allowed_cache_mutations=cache_writes,oldexec_seed_preloaded=mode=='negative_old_exec',oldexec_seed_SHA256=hashlib.sha256(seed).hexdigest()if seed else None);os.write(LOG,(json.dumps(row,sort_keys=True)+'\n').encode());os.close(LOG)
atexit.register(finish)
def mutate(q):
 case=cfg.get('api_patch');n=q['native_request']
 if case=='tuple':n['native_input']['time_request']['evidence']=tuple(n['native_input']['time_request']['evidence'])
 elif case=='integer_key':n['native_input']['binding']={0:'not-a-string-key'}
 elif case=='dict_subclass':
  class SubDict(dict):pass
  n['native_input']['chart']['pillars']=SubDict(n['native_input']['chart']['pillars'])
 elif case=='nonfinite':n['extra']=float('nan')
 elif case=='surrogate':n['extra']='\ud800'
 elif case=='cycle':n['cycle']=n
 elif case is not None:raise AssertionError('unregistered reviewer patch')
 return q
if mode=='api':
 module=runpy.run_path(str(P/'v1_entry.py'));request=mutate(json.loads(Path(sys.argv[2]).read_text()));v=module['execute'](request);print(module['C'].canonical(v));raise SystemExit(0 if v['entry_status']=='executed'else 2)
if mode=='script':
 script=Path(sys.argv[2]);args=json.loads(sys.argv[3]);original_isolated=sys.argv[4]=='1';sys.argv=[str(script),*args]
 if not original_isolated:sys.path.insert(0,str(script.parent))
 runpy.run_path(str(script),run_name='__main__');raise SystemExit(0)
if mode.startswith('negative_'):
 try:
  if mode=='negative_old_read':probe.read_bytes()
  elif mode=='negative_old_scan':list(os.scandir(OLD))
  elif mode=='negative_old_exec':exec(compile(seed,str(probe),'exec'),{})
  elif mode=='negative_package_write':
   with(P/'v1_entry.py').open('ab')as f:f.write(b'actual independent449 write attempt')
  else:raise AssertionError('negative mode')
 except RuntimeError:pass
 key=mode[len('negative_'):];assert counts[key]==1 and sum(counts.values())==1 and blocked;print(json.dumps(dict(mode=mode,actual_attempt_blocked=True,counts=counts)));raise SystemExit(0)
raise AssertionError('mode')
