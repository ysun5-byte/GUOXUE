# -*- coding: utf-8 -*-
"""Unmodified adopted native reference, never C08 integration code."""
from pathlib import Path
import sys,json,runpy
sys.dont_write_bytecode=True
entry,api,request=sys.argv[1:];module=runpy.run_path(entry);value=module[api](json.loads(Path(request).read_text()));print(json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False))
