# -*- coding: utf-8 -*-
from pathlib import Path
from hashlib import sha256
from collections import Counter
import json,zipfile,gzip,ast
D=Path(__file__).resolve().parent;ack=json.loads((D/'prior/final_frozen_delivery_target_acknowledged.json').read_text());P=Path(ack['package']);docs=json.loads((P/'运行整合层_20个算法解释.json').read_text());h=json.loads((D.parent/'C08_author_final_delivery_handoff.json').read_text());oldP=Path(h['directory']);source={};observed={};lambdas=[]
def walk(nodes,rel,prefix=''):
 for n in nodes:
  if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)):
   observed[rel+':'+prefix+n.name]=n;walk(n.body,rel,prefix+n.name+'.')
  elif isinstance(n,ast.ClassDef):walk(n.body,rel,prefix+n.name+'.')
for rel in ['delivery_common.py','v1_entry.py','native_worker.py','prepare_runtime.py','research_files.py']:
 raw=(P/rel).read_bytes();source[rel]=raw;t=ast.parse(raw);walk(t.body,rel)
 for n in ast.walk(t):
  if isinstance(n,ast.Lambda):lambdas.append(dict(path=rel,line=n.lineno,operation='8MiB read thunk within documented volume_digest streaming operation'))
assert len(observed)==20 and len(lambdas)==1 and set(observed)=={x['id']for x in docs['functions']}
with zipfile.ZipFile(P/'交付验证证据_C08.zip')as z:
 stem='C08_runtime_integration_after612/actual_transport_helpers_current_IO/';io=json.loads(gzip.decompress(z.read(stem+'first_complete_actual_IO_by_definition.json.gz')));receipt=json.loads(z.read(stem+'capture_receipt.json'));phaseout={k:gzip.decompress(z.read(stem+k+'.stdout.gz'))for k in ['entry_main','worker_main','prepare_main','research_main','constant']}
assert len(io)==33 and receipt['actual_documented_named_definitions20']==20
rows=[]
for r in docs['functions']:
 n=observed[r['id']];assert n.lineno==r['line'];assert sha256(ast.dump(n,include_attributes=False).encode()).hexdigest()==r['AST_sha256'];assert sha256(source[r['path']]).hexdigest()==r['source_sha256'];ref=r['current_actual_IO_reference'];a=io[ref['record']];assert a['source_file']==r['path']and a['source_sha256']==r['source_sha256']and a['line']==r['line'];args=[x.arg for x in n.args.posonlyargs+n.args.args+n.args.kwonlyargs];assert args==r['arguments']and set(a['input'])==set(args);assert'return_event_value'in a and a['return_event_is_not_proof_no_exception']is True;ct=r['algorithm_contract'];assert all(ct[k]for k in ['purpose','inputs','operations','outputs','preconditions_and_limits']);rows.append(dict(id=r['id'],source_AST_moduleSHA_current=True,real_complete_first_defined_argument_return_pair=True,source_layer=r['source_layer'],phase=a['phase']))
def record(name):return io[next(r['current_actual_IO_reference']['record']for r in docs['functions']if r['id']==name)]
c=record('delivery_common.py:canonical');assert c['return_event_value']==json.dumps(c['input']['value'],ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False)
api=record('v1_entry.py:execute');assert json.loads(phaseout['entry_main'])==api['return_event_value'];assert record('v1_entry.py:main')['return_event_value']==2 and api['return_event_value']['entry_status']=='rejected';assert api['return_event_value']['native_report']is None
worker=record('native_worker.py:dispatch');assert json.loads(phaseout['worker_main'])==worker['return_event_value'];assert record('native_worker.py:main')['return_event_value']==0 and worker['return_event_value']['ok']is False;assert worker['return_event_value']['native_provider_exec']>=1
prep=record('prepare_runtime.py:prepare');assert json.loads(phaseout['prepare_main'])==prep['return_event_value'];assert prep['return_event_value']['status']=='exact_runtime_prepared'and prep['return_event_value']['components']==1 and record('prepare_runtime.py:main')['return_event_value']is None
fetch=record('research_files.py:fetch');ret=fetch['return_event_value'];assert ret['python_type']=='bytes'and bytes.fromhex(ret['hex'])==phaseout['research_main'];assert record('research_files.py:main')['return_event_value']==0
constant=record('delivery_common.py:strict_load.constant');assert constant['input']==dict(value='NaN')and constant['return_event_value']is None;assert json.loads(phaseout['constant'])==dict(type='ValueError',message='nonfinite_JSON_constant')
module=record('delivery_common.py:native_module');assert module['input']['path']['python_type'].startswith('pathlib.')and module['return_event_value']['python_type']=='builtins.module';assert module['input']['path']['value']in module['return_event_value']['repr']
path=record('delivery_common.py:safe_path');assert path['return_event_value']['python_type'].startswith('pathlib.');assert Path(path['return_event_value']['value'])==Path(path['input']['base']['value'])/path['input']['relative']
match=record('delivery_common.py:matched');assert match['return_event_value']is None;value=Path(match['input']['path']['value']);rel=str(value.relative_to(oldP));meta=match['input']['meta'];raw=(P/rel).read_bytes();assert(len(raw),sha256(raw).hexdigest())==(meta['bytes'],meta['sha256'])
volume=record('prepare_runtime.py:volume_digest');v=volume['return_event_value'];assert v['python_type']=='tuple'and len(v['items'])==2;catalog=json.loads((P/'runtime_catalog.json').read_text());volpath=Path(volume['input']['path']['value']);relative=str(volpath.relative_to(oldP));expected=next(x for x in catalog['volumes'].values()if x['relative_path']==relative);assert v['items']==[expected['bytes'],expected['sha256']]
report=dict(status='frozen_r0_all20_docs_AST_sourceSHA_real_IO_substantive_audit_pass',named_definitions20=True,inline_read_lambda1_covered_in_parent_operations=True,recorded_profile_frames33_not33_algorithms=True,first_defined_args_and_returns_complete_not_all_paths=True,modules_and_code_context_not_heap_snapshot=True,normal_cli_native_rejection_exit2_not_capture_wrapper_exit0=True,worker_process_exit0_doesnot_mean_rule_success=True,constant_None_is_confirmed_exception_unwind=True,source_reader_real_bytes_exact=True,no_new_native_or_math_calls=True,r0_scope='Original frozen20 helper files still exact after true move. Source catalog r0 has379 separate collection omissions already reported; this IO audit does not waive them or imply readerdata complete. R1 delta will need separate current source/reader verification.',rows=rows)
(D/'actual/frozen_r0_transport20_docs_actual_IO_substantive_audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items()if k!='rows'},ensure_ascii=False,indent=2))
