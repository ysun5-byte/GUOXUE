# -*- coding: utf-8 -*-
from pathlib import Path
from hashlib import sha256
import json,tempfile,os,time
D=Path(__file__).resolve().parent;W=D.parent;H=W/'C08_author_final_delivery_handoff.json';hb=H.read_bytes();assert sha256(hb).hexdigest()=='3cbef2b85369cce6e31f1a38bff713a0435e17b7fc522e33ed6167d814de7a73';h=json.loads(hb);P=Path(h['directory']).resolve();manifest=P/'DELIVERY_MANIFEST.json';mb=manifest.read_bytes();assert sha256(mb).hexdigest()=='4788f9c203f3276edb5b9b85732228cbc6074a133374551204b8e5cdef8bf086';files=json.loads(mb)['files'];assert len(files)==272
fr=(P/'DELIVERY_FREEZE.json').read_bytes();assert sha256(fr).hexdigest()=='81e2f0048592d9a9260c97af5e1d2d78f89320332e32e6797742ba8b7d41d80e'
def filehash(p):
 s=sha256();n=0
 with p.open('rb')as f:
  for b in iter(lambda:f.read(8*1024*1024),b''):s.update(b);n+=len(b)
 return n,s.hexdigest()
def permanent(root):return{str(p.relative_to(root))for p in root.rglob('*')if p.is_file()and not p.is_relative_to(root/'prepared_runtime')}
assert permanent(P)==set(files)|{'DELIVERY_MANIFEST.json','DELIVERY_FREEZE.json'}
before={};start=time.time()
for rel,pin in files.items():
 p=P/rel;assert not p.is_symlink();actual=filehash(p);assert actual==(pin['bytes'],pin['sha256']),rel;st=p.stat();before[rel]=dict(bytes=actual[0],sha256=actual[1],mode=st.st_mode,device=st.st_dev,inode=st.st_ino)
assert sum(v['bytes']for v in before.values())==5406621574
parent=Path(tempfile.mkdtemp(prefix='C08 independent449 true moved final research ')).resolve();assert P.stat().st_dev==parent.stat().st_dev;destination=parent/'Part1 exact research native runtime with spaces';old=str(P);P.rename(destination)
assert not Path(old).exists()and permanent(destination)==set(files)|{'DELIVERY_MANIFEST.json','DELIVERY_FREEZE.json'}
for rel,row in before.items():
 st=(destination/rel).stat();assert (st.st_dev,st.st_ino,st.st_mode,st.st_size)==(row['device'],row['inode'],row['mode'],row['bytes']),rel
locator=W/'C08_runtime_integration_after612/candidate_location.json';prior=json.loads(locator.read_text());prior.setdefault('historical_locations',[]).append(dict(path=prior['path'],meaning='author final freeze location before independent sameFS true move'));prior.update(path=str(destination),independent449_true_relocation=True,no_large_clone=True);locator.write_text(json.dumps(prior,ensure_ascii=False,indent=2)+'\n')
report=dict(schema='C08-independent449-final274-permanent-true-relocation/0.1',all274_permanent_files_present=True,all272_payload_full_stream_bytes_SHA_pass=True,payload_bytes=5406621574,manifest_sha256=sha256(mb).hexdigest(),freeze_sha256=sha256(fr).hexdigest(),old_author_location=old,new_current_unique_location=str(destination),same_filesystem_rename_no_clone=True,all272_file_inodes_modes_and_sizes_preserved=True,generated_prepared_cache_excluded_from_permanent_manifest_as_declared=True,unified_native_calls_before_this_step=0,elapsed=time.time()-start)
(D/'actual/final274_full_stream_pin_and_true_move.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');ack=dict(final_author_frozen=True,target_pins_checked=True,package=str(destination),author_handoff=dict(path=str(H),bytes=len(hb),sha256=sha256(hb).hexdigest()),all_permanent_files=before,source_freeze_review_receipt='actual/final274_full_stream_pin_and_true_move.json');(D/'prior/final_frozen_delivery_target_acknowledged.json').write_text(json.dumps(ack,ensure_ascii=False,indent=2)+'\n');print(json.dumps(report,ensure_ascii=False,indent=2),flush=True)
