# -*- coding: utf-8 -*-
"""Reviewer script copied to a private temporary fixture, then run by guard."""
from pathlib import Path
from hashlib import sha256
import json,runpy,sys,os,subprocess,time
cfg=json.loads(Path(os.environ['C08_REVIEW449_GUARD_CONFIG']).read_text());P=Path(cfg['package']);Q=json.loads(Path(sys.argv[1]).read_text());OUT=Path(sys.argv[2]);OUT.mkdir()
m=runpy.run_path(str(P/'research_files_effective_r1.py'));rows=[];start=time.monotonic()
assert sha256((P/'research_files_effective_r1.py').read_bytes()).hexdigest()==Q['fixed_reader_SHA256']
for i,e in enumerate(Q['rows'],1):
 raw=m['fetch'](e['key']);assert sha256(raw).hexdigest()==e['sha256'];assert e['bytes']is None or len(raw)==e['bytes'];rows.append(dict(key=e['key'],bytes=len(raw),sha256=sha256(raw).hexdigest()))
 if i%40==0:print('actual effective reader complete files',i,flush=True)
assert len(rows)==379
negative=[]
for key,prefix in [(k,'historical_navigation_snapshot_bytes_unavailable:')for k in Q['old_two_keys']]+[('work/来源索引_current.json','mutable_source_index_requires_explicit_snapshot_version_or_SHA'),(False,'relative_research_key_required')]:
 try:m['fetch'](key)
 except ValueError as e:assert str(e).startswith(prefix);negative.append(dict(key=key,error=str(e)))
 else:raise AssertionError(('expected explicit rejection',key))
# A genuine read fault at the effective catalog boundary must fail its fixed SHA.
original=Path.read_bytes
def faulty(self):
 b=original(self)
 return b+b'\nindependent-r1-read-byte-fault'if self.resolve()==P/'research_catalog_effective_r1.json'else b
Path.read_bytes=faulty
try:
 try:m['fetch'](Q['rows'][0]['key'])
 except ValueError as e:assert str(e)=='fixed_research_catalog_required';negative.append(dict(case='actual_catalog_read_byte_fault',error=str(e)))
 else:raise AssertionError('catalog fault was accepted')
finally:Path.read_bytes=original
assert sha256(m['fetch'](Q['rows'][0]['key'])).hexdigest()==Q['rows'][0]['sha256']
# Complete ordinary public CLI, inherited into another Python guard process.
e=min(Q['rows'],key=lambda x:x['bytes']if x['bytes']is not None else 10**20)
r=subprocess.run([sys.executable,'-I','-B',str(P/'research_files_effective_r1.py'),'show',e['key']],capture_output=True,timeout=120)
assert r.returncode==0 and not r.stderr and sha256(r.stdout).hexdigest()==e['sha256'];(OUT/'actual_CLI_complete_source.bin').write_bytes(r.stdout)
report=dict(all_passed=True,actual_production_fetch379=len(rows),actual_source_bytes=sum(r['bytes']for r in rows),actual_public_CLI_complete_bytes=len(r.stdout),actual_public_CLI_SHA256=sha256(r.stdout).hexdigest(),same_actual_fixed_r1_reader_not_reimplemented=True,source_catalog_byte_fault_then_restoration=True,two_historical_SHA_explicitly_unavailable_no_substitution=True,negative=negative,rows=rows,elapsed_seconds=time.monotonic()-start,no_native_or_math=True)
(OUT/'complete_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print('independent379 actual production fetch passed',flush=True)
