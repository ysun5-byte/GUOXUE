# -*- coding: utf-8 -*-
"""Run only after a separately verified final author freeze acknowledgement."""
from pathlib import Path
from hashlib import sha256
from copy import deepcopy
import sys,os,json,gzip,tempfile,subprocess,ast,shutil,time
D=Path(__file__).resolve().parent
ack=json.loads((D/'prior/final_frozen_delivery_target_acknowledged.json').read_text());assert ack['final_author_frozen']and ack['target_pins_checked'];P=Path(ack['package']).resolve();OLD=D.parent.parent
assert not P.is_relative_to(OLD),'Run real moved package before final persistent rename, never treat old tree as new target'
def canon(v):return(json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False)+'\n').encode()
def pin(p):b=p.read_bytes();return dict(path=str(p.resolve()),bytes=len(b),sha256=sha256(b).hexdigest())
version=next(ast.literal_eval(n.value)for n in ast.parse((P/'v1_entry.py').read_text()).body if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='VERSION'for t in n.targets));M=json.loads((P/'route_manifest.json').read_text());C=json.loads((P/'runtime_catalog.json').read_text());routes={r['route_id']:r for r in M['routes']};assert len(routes)==138 and len(C['components'])==96
cases=json.loads((D/'prior/02_full_native_expected_seal_before_unified_calls.json').read_text())['cases']
for name in ['03_original251_C20_full_expected_before_unified_calls.json','04_final621_full_native_expected_before_unified_calls.json','05_affected232_positive_full_expected_before_unified_calls.json']:cases.append(json.loads((D/'prior'/name).read_text()))
assert len(cases)==11
T=Path(tempfile.mkdtemp(prefix='C08 independent449 final moved delivery review ')).resolve();runner=T/'inherited_review_runner.py';runner.write_bytes((D/'inherited_review_runner.py').read_bytes());OUT=D/'actual/final_unified';OUT.mkdir(exist_ok=False);configs=[];rows=[]
for case in cases:
 q=Path(case['request']['path']);b=q.read_bytes();assert(len(b),sha256(b).hexdigest())==(case['request']['bytes'],case['request']['sha256']);native=json.loads(b)
 if case['route_id']=='symbolic.compose':native=native['native_request']
 case['outer']=dict(schema_version=version,route_id=case['route_id'],native_request=native)
def config(case,**extra):
 p=T/(case+'.config.json');log=T/(case+'.audit.jsonl');v=dict(package=str(P),old_project=str(OLD),audit_log=str(log),**extra);p.write_text(json.dumps(v)+'\n');configs.append((case,p,log));return p,log
def run(case,mode,q=None,cli=None,allow_cache=False,**extra):
 cfg,log=config(case,allow_cache_preparation=allow_cache,**extra);env=dict(os.environ,C08_REVIEW449_GUARD_CONFIG=str(cfg))
 if q is not None:p=T/(case+'.request.json');p.write_bytes(canon(q))
 if mode=='api':args=['api',str(p)]
 elif mode=='script':args=['script',str(P/'v1_entry.py'),json.dumps([str(cli)]),'1']
 elif mode=='prepare':args=['script',str(P/'prepare_runtime.py'),json.dumps(['--component',*cli]),'1']
 else:args=[mode]
 r=subprocess.run([sys.executable,'-I','-B',str(runner),*args],capture_output=True,env=env,cwd=str(T),timeout=1800);(OUT/(case+'.stdout.gz')).write_bytes(gzip.compress(r.stdout,mtime=0));(OUT/(case+'.stderr.log')).write_bytes(r.stderr);audit=[json.loads(s)for s in log.read_text().splitlines()]if log.exists()else[]
 if mode!='prepare':assert not r.stderr,(case,r.returncode,r.stderr[-2000:])
 return r,audit
def normal_audit(audit,prepare_allowed=False):
 assert audit and not any(any(x['counts'].values())for x in audit),audit
 assert prepare_allowed or not any(x['allowed_cache_mutations']for x in audit)
 for x in audit:
  if x['allowed_cache_mutations']:assert x['explicit_prepare_child']
components=sorted({'__legacy_v1_entry071__'if routes[c['route_id']]['transport_kind']=='legacy31'else routes[c['route_id']]['component']for c in cases})
# Only selected finite components, never an all96 materialization gate.
r,audit=run('selected_component_preparation','prepare',cli=components,allow_cache=True);assert r.returncode==0;receipt=json.loads(r.stdout);assert receipt['components']==len(components);normal_audit(audit,True);rows.append(dict(case='selected_component_preparation',components=components,receipt=receipt,actual_guarded_processes=len(audit),allowed_cache_mutations=sum(x['allowed_cache_mutations']for x in audit),old_project_actions0=True))
for case in cases:
 r,audit=run(case['id'],'api',q=case['outer']);v=json.loads(r.stdout);expected_rejected=case['id']=='old31_composer_unknown_cannot_hide_badP';assert r.returncode==(2 if expected_rejected else 0);assert v['entry_status']==('rejected'if expected_rejected else'executed');assert v['native_report']is not None
 raw=canon(v['native_report']);e=case['full_expected'];assert(len(raw),sha256(raw).hexdigest())==(e['uncompressed_bytes'],e['uncompressed_with_LF_sha256']),case['id'];assert v['new_B_or_display_adapter']is False and v['real_prediction_validated']is False;normal_audit(audit)
 rows.append(dict(case=case['id'],full_native_report_bytes=len(raw),full_native_report_SHA256=sha256(raw).hexdigest(),entry_status=v['entry_status'],full_expected_presealed=True,actual_processes=len(audit),actual_wrapped_children=sum(x['wrapped_python_children']for x in audit),native_provider_exec_this_worker_only=v.get('native_provider_exec'),native_scope_kind=v.get('native_scope_kind'),all_forbidden_actions0=True))
 (OUT/'durable_passed_rows.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n');print(case['id']+' full report passed',flush=True)
for source,target in [('619_complete','research.rev609_Yanshang404_actual_five_layer_adaptation'),('616_complete','research.rev569_Jiase384_actual_five_layer_adaptation')]:
 q=deepcopy(next(c['outer']for c in cases if c['id']==source));q['route_id']=target;ident='cross_'+source;r,audit=run(ident,'api',q=q);v=json.loads(r.stdout);assert r.returncode==2 and v['entry_status']=='rejected'and v['native_report']is None and v.get('ok')is False;normal_audit(audit);rows.append(dict(case=ident,selected_schema_rejected=True,actual_processes=len(audit),native_provider_exec=v.get('native_provider_exec'),no_fallback=True))
seed=next(c['outer']for c in cases if c['id']=='619_complete')
for kind in ['tuple','integer_key','dict_subclass','nonfinite','surrogate','cycle']:
 ident='strict_API_'+kind;r,audit=run(ident,'api',q=seed,api_patch=kind);v=json.loads(r.stdout);assert r.returncode==2 and v['entry_status']=='rejected'and v['native_report']is None and sum(x['wrapped_python_children']for x in audit)==0;normal_audit(audit);rows.append(dict(case=ident,rejected_before_any_worker=True,actual_processes=len(audit),issues=v['issues']))
small=next(c for c in cases if c['id']=='397_source_only');route=routes[small['route_id']];spec=C['components'][route['component']];base=P/'prepared_runtime'/spec['relative_runtime_path'];policy=spec['policy_file'];assert policy in json.loads((P/'package_pins.json').read_text())['files']
for tag,target,workers in [('source',base/route['public_entry_file'],1),('policy',P/policy,0)]:
 ident='bad_'+tag;r,audit=run(ident,'api',q=small['outer'],fault_path=str(target));v=json.loads(r.stdout);assert r.returncode==2 and v['native_report']is None and v['entry_status']=='rejected';normal_audit(audit);assert sum(x['wrapped_python_children']for x in audit)==workers and sum(x['controlled_read_faults']for x in audit)>=1
 if tag=='source':assert v['native_provider_exec']==0
 rows.append(dict(case=ident,actual_read_fault_before_native=True,actual_worker_launches=workers,native_report_null=True))
r,audit=run('restored_source_policy','api',q=small['outer']);v=json.loads(r.stdout);assert r.returncode==0 and(len(canon(v['native_report'])),sha256(canon(v['native_report'])).hexdigest())==(small['full_expected']['uncompressed_bytes'],small['full_expected']['uncompressed_with_LF_sha256']);normal_audit(audit);rows.append(dict(case='restored_source_policy',complete_original_report_exact=True))
for ident in ['619_complete','affected232_complete_positive_C0']:
 case=next(c for c in cases if c['id']==ident);p=T/(ident+'.ordinary_CLI.request.json');p.write_bytes(canon(case['outer']));r,audit=run(ident+'_CLI','script',cli=p);v=json.loads(r.stdout);assert r.returncode==0;raw=canon(v['native_report']);e=case['full_expected'];assert(len(raw),sha256(raw).hexdigest())==(e['uncompressed_bytes'],e['uncompressed_with_LF_sha256']);normal_audit(audit);rows.append(dict(case=ident+'_CLI',full_native_report_exact=True,whole_outer_CLI_is_canonical=r.stdout==canon(v),actual_processes=len(audit)))
p=T/'duplicate_CLI.json';p.write_text('{"schema_version":1,"schema_version":2,"route_id":"x","native_request":{}}');r,audit=run('strict_duplicate_CLI','script',cli=p);v=json.loads(r.stdout);assert r.returncode==2 and v['native_report']is None and not any(x['wrapped_python_children']for x in audit);normal_audit(audit);rows.append(dict(case='strict_duplicate_CLI',rejected_before_worker=True))
for kind in ['old_read','old_scan','old_exec','package_write']:
 r,audit=run('negative_'+kind,'negative_'+kind);assert r.returncode==0 and json.loads(r.stdout)['actual_attempt_blocked'];assert len(audit)==1 and audit[0]['counts'][kind]==1 and sum(audit[0]['counts'].values())==1;rows.append(dict(case='negative_'+kind,actual_attempt_blocked=True))
all_logs=[]
for case,cfg,log in configs:
 if log.exists():
  b=log.read_bytes();(OUT/(case+'.actual_all_process_audit.jsonl')).write_bytes(b);all_logs.extend(json.loads(s)for s in b.splitlines())
report=dict(schema='C08-genuine-independent449-final-actual-delivery-campaign/0.1',all_passed=True,only_existing_package=str(P),no_large_package_clone=True,full_presealed_native_reports11=True,actual_complete_CLI2=True,source_and_policy_actual_read_faults2_restore=True,strict_Python_API6_and_duplicateCLI=True,cross_schema2=True,four_actual_negative_controls=True,guard_inherited_by_all_Python_children=True,actual_processes=len(all_logs),actual_wrapped_python_children=sum(x['wrapped_python_children']for x in all_logs),explicit_preparation_writes_only_owned_cache=True,positive_forbidden_actions0=True,math_count_not_instrumented_or_invented=True,no_95_internal_campaigns_repeated=True,root_adoption_not_self_awarded=True,rows=rows,review_fixture_root=str(T))
(OUT/'complete_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print('final independent unified delivery campaign passed',flush=True)
