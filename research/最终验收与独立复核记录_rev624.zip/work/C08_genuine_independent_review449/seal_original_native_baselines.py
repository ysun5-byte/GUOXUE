# -*- coding: utf-8 -*-
from pathlib import Path
from hashlib import sha256
import json,gzip,subprocess,sys
D=Path(__file__).resolve().parent;P=D/'prior/01_exact_new_inputs_and_behavior_before_reference_calls.json';cases=json.loads(P.read_text())['cases'];OUT=D/'prior/complete_native_expected';OUT.mkdir(exist_ok=True);actual=[]
def check_pin(pin):p=Path(pin['path']);v=p.read_bytes();assert(len(v),sha256(v).hexdigest())==(pin['bytes'],pin['sha256']);return v
def canonical(value):return(json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False)+'\n').encode()
for row in cases:
 check_pin(row['request']);check_pin(row['original_public_entry'])
 if row['run_unmodified_original_baseline']:
  result=subprocess.run([sys.executable,'-I','-B',str(D/'reference_baseline_child.py'),row['original_public_entry']['path'],row['API'],row['request']['path']],capture_output=True);(D/'actual'/(row['id']+'.reference.stderr.log')).write_bytes(result.stderr);(D/'actual'/(row['id']+'.reference.raw.stdout.gz')).write_bytes(gzip.compress(result.stdout,mtime=0))
  assert result.returncode==0 and not result.stderr,(row['id'],result.returncode,result.stderr.decode()[-2000:]);v=json.loads(result.stdout);origin='new request executed only in original adopted frozen public reference; not final C08 and not new independent mathematical oracle'
 else:v=json.loads(gzip.decompress(check_pin(row['known_complete_golden'])));origin='original frozen complete golden, previously genuinely independently reviewed'
 if row['id']=='new619_same_function_new_records':assert v['comparison']['status']=='calculation_confirmed_same'and v['comparison']['source_record_identity_changed']and v['distinct_typed_inventory_calculations']==1
 if row['id']=='new616_gap_to0040':assert v['comparison']['status']=='evidence_insufficient_to_confirm_changed_or_same'and not v['comparison']['change_or_same_confirmed']and not v['current']['all_requested_frames_known']
 if row['id']=='397_source_only':assert v['status']=='source_path_conditions_met'and v['whole_auxiliary_conclusion']is None and len(v['virtual_paths'])==3 and all(r['actual_root_credit']is None and r['physical_quantity']is None for r in v['virtual_paths'])
 if row['id']=='old31_composer_timegap':assert v['entry_status']=='executed'and v['native_report']['status']=='instant_undetermined'and v['native_report']['Z']is None
 if row['id']=='old31_composer_unknown_cannot_hide_badP':assert v['entry_status']=='rejected'and v['native_report']['status']=='invalid_input'and v['native_report']['issues']==[dict(path='inputs.P.event',code='unknown_field')]
 wire=canonical(v);p=OUT/(row['id']+'.json.gz');p.write_bytes(gzip.compress(wire,mtime=0));b=p.read_bytes();actual.append(dict(id=row['id'],request=row['request'],route_id=row['route_id'],full_expected=dict(path=str(p),bytes=len(b),sha256=sha256(b).hexdigest(),uncompressed_bytes=len(wire),uncompressed_with_LF_sha256=sha256(wire).hexdigest()),basis=origin,semantic_prior_passed=True))
 (D/'actual/reference_baseline_progress.json').write_text(json.dumps(dict(completed=actual,final_C08_native_calls=0),ensure_ascii=False,indent=2)+'\n');print(row['id']+' complete reference saved',flush=True)
report=dict(schema='C08-independent449-full-native-expectations-sealed-before-unified-call/0.1',new_original_reference_calls=5,existing_frozen_golden_references=3,final_C08_native_calls=0,no_current_unified_output_used_as_oracle=True,mathematical_truth_reused_from_component_independent_reviews_not_new_prediction_proof=True,canonicalization='Entire native JSON value preserved; sorted UTF8/LF canonical comparison. Original CLI ASCII/pretty formatting not falsely claimed wire-identical to new wrapper.',cases=actual)
(D/'prior/02_full_native_expected_seal_before_unified_calls.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print('8 full expectations sealed; finalC08 calls0')
