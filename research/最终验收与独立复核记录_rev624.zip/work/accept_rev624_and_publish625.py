# -*- coding: utf-8 -*-
"""Record the root's final evidence decision; never run before genuine review."""
from pathlib import Path
from datetime import datetime, timezone
from decimal import Decimal
import copy
import hashlib
import json
import sys
import zipfile

W = Path(__file__).resolve().parent
R = W.parent
sys.path.insert(0, str(W))
from research_record_helpers import read_json as read, write_json as write, file_ref as ref, seal_record_copies, verify_frozen_tree

cfg = read(W / 'C08_final_root_acceptance_inputs.json')
assert cfg['root_substantive_review_complete'] is True
assert cfg['genuine_R1_review_all_passed'] is True
assert cfg['stable_same_filesystem_move_and_relative_checks_passed'] is True
for p in cfg['checked_evidence'].values():
    actual = ref(p['path'])
    assert (actual['bytes'], actual['sha256']) == (p['bytes'], p['sha256']), p['path']

P = Path(cfg['stable_delivery_directory'])
assert P == R / 'outputs/Part1_研究成果_统一可复现交付'
author = read(W / 'C08_author_effective_r1_delivery_handoff.json')
mf = P / 'DELIVERY_MANIFEST_r1.json'
fr = P / 'DELIVERY_FREEZE_r1.json'
assert ref(mf)['sha256'] == author['combo_manifest']['sha256']
assert ref(fr)['sha256'] == author['combo_freeze']['sha256']
assert read(fr)['manifest_sha256'] == ref(mf)['sha256']
table = read(mf)['files']
assert len(table) == 283
assert sum(v['bytes'] for v in table.values()) == 5528208609
actual_names = {str(p.relative_to(P)) for p in P.rglob('*') if p.is_file() and p.relative_to(P).parts[0] != 'prepared_runtime'}
assert actual_names == set(table) | {mf.name, fr.name}
for name, expected in table.items():
    rel = Path(name)
    assert not rel.is_absolute() and '..' not in rel.parts
    p = P / rel
    assert not p.is_symlink() and p.stat().st_size == expected['bytes']
# Full permanent bytes, modes and source objects were independently read, not
# inferred from these stat checks. Bind the actual genuine review below.
for name in ['v1_entry.py', 'native_worker.py', 'delivery_common.py', 'prepare_runtime.py',
             author['effective_first_read'], author['effective_reader'], author['current20_explanations']]:
    actual = ref(P / name)
    assert (actual['bytes'], actual['sha256']) == (table[name]['bytes'], table[name]['sha256'])

original = R / 'outputs/Part1_生辰核与变色规则_接续研究包_v0.12/02_规则与进度/生成核_变色规则进度账本_v0.1.json'
assert ref(original)['sha256'] == 'fab4ab043eadb5def3cc703dd9e869db8cc724ab38154b318d53d7eaeedff3fd'
original_modules = read(original)['modules']
current = read(W / 'current_acceptance_registry.json')
assert current['score'] == '98.75'
assert {m['id']: m['stage'] for m in current['modules']} == {f'C{i:02d}': '0.75' if i == 8 else '1.00' for i in range(1, 9)}
for m, old in zip(current['modules'], original_modules):
    assert (m['id'], m['weight'], m['done_when']) == (old['id'], old['weight'], old['done_when'])

now = datetime.now(timezone.utc).isoformat()
D = W / 'rev624_C08_original_full_acceptance'
D.mkdir(exist_ok=False)
reason = '''原C08完整验收裁决

沿原八模块、原权重5和原done_when“全链在约定支持范围内完成开发回放、边界、冲突及独立留出一致性复核”。本次只授原余下1.25分；原C02 570、C03 622与地区500等既有验收不重写，不把95方法、4958导航、138路或测试数量换算成进度。

全链保原规范JSON/31旧路、原251单人整盘H到已采用基础及P/T/C20/离开闭环，以及当前95研究方法各自精确原生合同。原生完整报告和各知识轴原样返回，已知阴性、计算后不变、资料不足未知、来源限定命题和结构错误分别处理。最后真正非作者在唯一目录真移位后，事先封完整预期再真实调用；最终含12份完整原生报告、2原生完整CLI和1资料完整CLI，严格类型/跨schema/坏源/坏政策及恢复都验证。首轮49进程/19 Python子启动正确域精确保留，追加615与当前reader后合计58真实进程/23 Python子启动，54正常进程禁用动作均为0，另4真实旧目录读扫执行和永久包写反控确被拦截。该证据验证接线和原报告保真，不冒95套内部数学全部重新求证。

首版来源收件器将旧size/SHA-only格式误读为空并错误报全通过，这是实质缺陷，原错误回执作为历史保留，不能用作最终完整性依据。独审定位379条路径：244条在原266已有字节而漏locator，135条原359研究源/实际I/O等须补收。R1逐95原清单规范49419路径、SHA和声明尺寸，保同SHA多路径，未知/空格式硬拒；244补精确旧成员位置，135原件按SHA去重117对象补卷。作者全95物理核验与379真实取件之后，真正非作者再次逐全表和最终目录全部对象实读SHA，并核实际生产取件、有效两reader解释/真实完整I/O、两历史拒用及最后285永久件。所有这部分新证据实际绑定R1；首274的运行代码/native/guard/原参数字节不变，只在精确未变化域复用原正确运行证据。

原501全部682资料、当前阅读增量、95逐方法原规则/算法解释、有效采用/来源修正、完整必要计算材料及当前20整合说明物理可取。20有效说明是18运输函数加2当前reader；旧reader解释留历史，不把物理22定义吹成22条新命理能力。来源按原文/注释/现代解释/工程约定分层；比例、阈值和共池等工程推论不冒古籍原数。规则资料核对、实现正确和现实预测验证三轴独立，现实预测验证计数仍0。

两份早期可变来源导航旧字节（6309/afaba…、8045/fc96…）确未找回，永久披露；所有捕获pointer、定向查找和失败恢复都保。它们不作为本次已采用规则/参数/必要I/O唯一依赖；读件器按精确两个SHA拒绝，不用当前索引、占位件或泛字段mask冒旧件。这一狭义历史目录限制没有豁免379条实源修复，也不豁免任何核心资料。历史操作回执曾被后次元数据编译覆盖，旧文件名不再被用来认证首次执行前的不可变时间戳；有效当前代码、I/O和真正独审另有实际证据。

唯一交付目录完成原地跨路径移动至稳定outputs，卷、读取器、运行器、输入说明、规则版本、来源和修正/验证记录一并可用。原成稿中98.75/pending/早期all_C03_complete=false是不可变捕获历史；当前根验收只覆盖全项状态，不回写旧来源、代码、数学或失败结论。新增个人基础主题/手环显示/物理呈现按用户指令仍后置；既有C05/C06/C07语义规则和原全链保留，并未用后置显示删减原规则。

在原约定有限V1范围，原全部必须交付项、来源/条件、必要判断链、必要行为与独立留出、运行/阅读/来源/变更资料和明确限制均达成。不是任意八字的普遍唯一解，不是自然历法/外部事实认证，也不是现实预测100%。不以unknown、默认或不支持顶未算核心。原C08由0.75到1.00，原总验收98.75到100.00，原任务交付完成。
'''
(D / 'root_substantive_acceptance_reason.txt').write_text(reason)
decision = dict(schema='624-original-C08-full-stage-and-original-task-acceptance/1', revision=624,
    status='accepted_original_C08_stage1_and_original_Part1_delivery_complete', saved_utc=now,
    module='C08', weight=5, original_done_when=original_modules[-1]['done_when'], original_ledger=ref(original),
    old_stage='0.75', new_stage='1.00', old_points='3.75', new_points='5.00', progress_delta='1.25',
    old_score='98.75', score='100.00', denominator=100, all_original_weights_scope_done_when_preserved=True,
    original_task_complete=True, all_required_original_deliverables_complete=True,
    no_unknown_default_or_unsupported_as_core_completion=True, quality_lowered=False,
    stable_delivery_directory=str(P), effective_first_read=author['effective_first_read'],
    manifest=ref(mf), freeze=ref(fr), independently_full_hashed_permanent_files=285,
    root_did_not_repeat_correct_native_math_or_large_archive_hash_campaign=True,
    checked_actual_evidence=cfg['checked_evidence'], root_reason=ref(D / 'root_substantive_acceptance_reason.txt'),
    known_limits=['two exact early historical navigation snapshot byte versions unavailable',
                  'specific overwritten early operational receipt cannot certify its original before-first-call timestamp',
                  'bounded method versions and source disagreements retained; not all possible charts/all schools universal truth',
                  'software acceptance is not empirical prediction validation',
                  'physical presentation and new display work remain deferred by user'],
    real_prediction_validation_count=0, new_B_RGB_or_physical_work=False)
dp = D / 'acceptance_decision.json'
write(dp, decision)
write(D / 'manifest.json', dict(files={p.name: {k: ref(p)[k] for k in ('bytes', 'sha256')} for p in D.iterdir() if p.is_file()}))
write(D / 'freeze.json', dict(manifest_sha256=ref(D / 'manifest.json')['sha256']))
verify_frozen_tree(D, ref(D / 'manifest.json')['sha256'], ref(D / 'freeze.json')['sha256'], 4)

public = R / 'outputs/Part1_研究成果_最终验收与使用说明_rev624.txt'
public.write_text('''Part1 研究成果最终交付与验收 rev624

原任务验收：100.00/100。C01—C08按原权重10/25/15/10/20/10/5/5均完成，最后C08原余1.25分已基于真正非作者运行、来源补收及整包核验授予；没有按篇幅、文件或算法条数加分。100%指原任务交付与验收，不代表命理预测准确率100%。

成果保存在本机项目的outputs和work。固定成品目录：
'''+str(P)+'''
先读成品内：00_0_当前有效入口_请先读_r1.txt。
研究正文从研究阅读/00_研究导航/95方法_逐规则与算法阅读导航.txt进入，再按精确方法看逐规则、逐算法说明。原501阅读资料与当前增量、原典/来源/完整计算材料可由当前取件器读取。95方法/4958导航是查找数量，不是独立理论总数或现实覆盖率。

运行版本：v1-capability-entry-research-0.8，资料修复发行r1；各方法仍保自己的原精确版本/口径与适用条件。统一请求只含schema_version、route_id、native_request三项，原生请求须按该方法合同填写。选路与完整示例见route_manifest.json、当前95方法_运行与来源登记.json、integration_tests。
运行：python3 -I -B v1_entry.py /包外/请求.json
列出研究资料：python3 -I -B research_files_effective_r1.py list-reading
读原件：python3 -I -B research_files_effective_r1.py show 资料键
提取到包外：python3 -I -B research_files_effective_r1.py extract 资料键 /包外/文件
全部命令均在成品目录执行，卷与相对位置一并保留；Python3.9及以上。无需联网或旧work目录。prepared_runtime是可生成缓存；坏的已有组件拒绝，不自动冒新版本修复。不要求同时展开全部组件。

当前资料读取默认是effective_r1，旧research_files.py/旧catalog和旧00/01的资料命令保历史。当前20整合算法说明是运行整合层_当前有效20个算法解释_r1.json，含18原运输与2当前资料取件算法；95研究方法自身的完整算法解释另在方法导航中。

已核：全部原约定模块的必要判断链与来源/条件、正反/边界/变化/回归与独立留出；实际原251整盘到原P/T/C20及离开链；独立真移位完整报告及类型/坏源/坏政策/恢复/负控；全95清单49419路径的资料实物与完整SHA、379条首版遗漏修复和当前真实取件；最终285永久件及稳定移动后相对入口。完整精确结论以本机work/rev624_C08_original_full_acceptance/acceptance_decision.json和绑定的作者/独审回执为准。
最终根裁决和真正非作者完整预期/实际复核过程另存同级Part1_最终验收与独立复核记录_rev624.zip；与统一成品一并保存即可。该小型证据附包没有再复制大资料卷。

保存限制：两份早期来源导航旧快照字节未找回，读件器明确拒取，未用当前版冒充；另一个早期操作回执不能凭旧文件名证明首次执行前不可变时间戳。这些记录及搜索/失败过程保留。必要规则、源码、参数与计算材料已实际核取，379遗漏没有借历史例外豁免。不能声称每份历史每个字节都完整保留，也未逐字另存所有聊天/工具输出。

原文/后注/现代解释/工程约定分别标注；已批准C20等比例不是古书原数。原局事实与当前输入、确认不变与尚不能判断保持区分。同一输入同一精确方法版本可复现，不同口径可以不同断。现实预测效力未因此得到证明。新增个人基础主题接合/手环显示/物理设计仍依用户要求后置，原已批准规则与既有语义链保存。

'''+reason+'\n精确永久清单：\n'+json.dumps(dict(manifest=ref(mf), freeze=ref(fr)),ensure_ascii=False,indent=2)+'\n')
independent_dir = W/'C08_genuine_independent_review449'
evidence_paths = {p for p in independent_dir.rglob('*') if p.is_file()}
evidence_paths.update(Path(p['path']) for p in cfg['checked_evidence'].values())
evidence_paths.update([dp,D/'root_substantive_acceptance_reason.txt',D/'manifest.json',D/'freeze.json',
                       W/'C08_final_root_acceptance_inputs.json',Path(__file__),public])
evidence_rows=[]
for p in sorted(evidence_paths):
    assert not p.is_symlink() and p.is_relative_to(R)
    info=ref(p)
    assert info['bytes']<200000000, 'Evidence archive must not duplicate large source volumes.'
    evidence_rows.append(dict(info,member=str(p.relative_to(R))))
evidence_index=W/'rev624_final_evidence_archive_index.json'
write(evidence_index,dict(schema='624-final-root-and-genuine-independent-evidence-archive-index/1',
    files=evidence_rows,index_itself_bound_by_outer_archive_SHA=True,
    archive='outputs/Part1_最终验收与独立复核记录_rev624.zip',
    not_a_second_copy_of_the_large_research_distribution=True))
evidence_archive=R/'outputs/Part1_最终验收与独立复核记录_rev624.zip'
assert not evidence_archive.exists()
with zipfile.ZipFile(evidence_archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for row in evidence_rows:
        p=Path(row['path'])
        z.write(p,row['member'],compress_type=zipfile.ZIP_STORED if p.suffix in ('.gz','.zip') else zipfile.ZIP_DEFLATED)
    z.write(evidence_index,str(evidence_index.relative_to(R)))
with zipfile.ZipFile(evidence_archive) as z:
    assert set(z.namelist())=={r['member']for r in evidence_rows}|{str(evidence_index.relative_to(R))}
    for row in evidence_rows:
        raw=z.read(row['member'])
        assert (len(raw),hashlib.sha256(raw).hexdigest())==(row['bytes'],row['sha256'])
registration = W / 'rev624_C08_full_acceptance_registration.json'
write(registration, dict(status=decision['status'], decision=ref(dp), public=ref(public), module='C08', old_stage='0.75', new_stage='1.00', old_score='98.75', score='100.00', progress_delta='1.25', denominator=100, remaining_total_points='0.00', original_task_complete=True, final_independent_evidence_archive=ref(evidence_archive),final_evidence_archive_index=ref(evidence_index)))
seal_record_copies(W / 'rev624_acceptance_records', [registration, public])

backup = W / 'rev624_before_mutable_final_acceptance'
backup.mkdir()
current_names = ['current_acceptance_registry.json','current_continuation_state.json','rev72_root_checkpoint.json','生成核_变色规则进度账本_current.json']
for name in current_names + ['来源索引_current.json']:
    (backup / name).write_bytes((W / name).read_bytes())
(backup / 'SOURCE_OF_TRUTH.md').write_bytes((R / 'SOURCE_OF_TRUTH.md').read_bytes())
(backup / '研究成果总览_先读这一份.txt').write_bytes((R / 'outputs/研究成果总览_先读这一份.txt').read_bytes())
seal_record_copies(W / 'rev624_preupdate_record_pins', list(backup.iterdir()))

nav = read(W / 'rev623_current_algorithm_navigation.json')
assert len(nav['methods']) == 95 and len(nav['algorithm_navigation']) == 4958
for key in ['research_pending','current_research_pending_not_adopted','current_status_snapshot']:
    if key in nav:
        nav['historical_' + key + '_before625'] = copy.deepcopy(nav[key])
nav.update(version=625, saved_utc=now, progress='100.00', progress_components={f'C{i:02d}':'1.00' for i in range(1,9)},
    remaining_original_points=dict(C03='0.00',C08='0.00',total='0.00'), prior_navigation=ref(W/'rev623_current_algorithm_navigation.json'),
    all_original_task_complete=True, original_task_complete=True, research_pending={}, current_research_pending_not_adopted={},
    current_C08_acceptance=ref(dp), current_delivery_directory=str(P), current_manifest=ref(mf), current_first_read=author['effective_first_read'],
    current20_transport_reader_explanations=ref(P/author['current20_explanations']),
    current_status_snapshot='625 original task complete; legacy captured pending states remain historical only')
np = W/'rev625_current_algorithm_navigation.json'
write(np,nav)
cp = dict(schema='625-original-task-final-recoverable-checkpoint/1', checkpoint_revision=625, saved_utc=now,
    score='100.00', denominator=100, module_stages={f'C{i:02d}':'1.00' for i in range(1,9)}, remaining_points=dict(total='0.00'),
    original_ledger=ref(original), previous_checkpoint=ref(W/'rev623_live_checkpoint.json'), final_original_C08_acceptance=ref(dp),
    latest_progress_acceptance=ref(registration), latest_algorithm_index=ref(np), stable_delivery_directory=str(P),
    effective_first_read=author['effective_first_read'], delivery_manifest=ref(mf), delivery_freeze=ref(fr), final_public_guide=ref(public),
    final_independent_evidence_archive=ref(evidence_archive),final_evidence_archive_index=ref(evidence_index),
    original_task_complete=True, all_original_scope_quality_retained=True, active_tasks={}, remaining_original_acceptance={},
    user_pause_request_active=False, execution_status='original_task_complete', goal_status='complete',
    goal_tool_observation_precision='Task is achieved; exact manager update result is saved separately after publishing all artifacts.',
    known_limits=decision['known_limits'], real_prediction_validation_count=0, no_new_B_or_display=True,
    final_genuine_evidence=cfg['checked_evidence'], no_claim_background_after_turn_end=True)
cf = W/'rev625_live_checkpoint.json'
write(cf,cp)
guide = R/'outputs/当前研究与接续入口_rev625.txt'
guide.write_text('''Part1 最终研究与恢复入口 rev625

原任务按原范围和验收清单完成：100.00/100，八模块均1.00。新增显示与物理呈现仍后置，不属于本规则交付的新工作。
先读 outputs/研究成果总览_先读这一份.txt，再读 outputs/Part1_研究成果_最终验收与使用说明_rev624.txt。
固定成品：outputs/Part1_研究成果_统一可复现交付；其当前有效入口为00_0_当前有效入口_请先读_r1.txt。
逐方法规则与算法：成品研究阅读/00_研究导航/95方法_逐规则与算法阅读导航.txt；精确原件导航work/rev625_current_algorithm_navigation.json。95方法/4958导航不是进度分母。18原运输加2当前reader的20有效解释另列。
精确最终裁决work/rev624_C08_original_full_acceptance/acceptance_decision.json；最终检查点work/rev625_live_checkpoint.json。当前数据和SOT以本次原任务完成状态为准，原封存的pending/旧进度、旧收件全通过首错均保留历史，不能覆写或冒当前结论。
最终原C08由0.75到1.00，只授原余1.25分。全95来源49419路径、379遗漏修复、所有必要来源/规则/代码/I/O、真正非作者完整运行和资料取件、最终285永久件及稳定移动均有精确回执。未用默认或未知替核心，也不为正确资料修复重复95套大数学。
两份早期导航快照原字节未找回；一份早期被后次编译覆盖的操作回执不认证首次执行前时间戳。这些局限永久披露，真实必要资料修复不因此豁免。保存成果及关键过程，不宣称每份历史文件每字节或逐字聊天/工具均保存。100%是交付验收，不是现实预测准确率。
本页为归档后的恢复入口，不表示仍在后台运行。若以后开展新增任务，先核本次冻结版本与用户新授权。
''')
for name in current_names:
    path=W/name
    v=read(path)
    assert v['score']=='98.75'
    for key in ['current_remaining_points','active_current_original_remaining_after563','current_status_authority','goal_tool_last_reported_status',
                'goal_manager_last_observed_status','active_tasks','active_research_tasks','active_agents_next_batch','next_work',
                'latest_unified_entry','current_unified_entry','latest_published_research_directory','latest_research_revision',
                'current_original_remaining_acceptance','execution_status','in_progress_candidate','research_revision',
                'latest_published_research_revision','latest_published_research_archive','latest_published_research_sha256',
                'latest_published_research_verification','latest_archive','archive_sha256','latest_formal_package']:
        if key in v:
            v['historical_'+key+'_before624']=copy.deepcopy(v[key])
    v.update(score='100.00',weighted_score='100.00',display_percent='100%',denominator=100,score_changed=True,
        module_stages={f'C{i:02d}':'1.00' for i in range(1,9)},remaining_total_points='0.00',
        current_remaining_points=dict(C03='0.00',C08='0.00',total='0.00'),current_original_remaining_acceptance={},
        active_current_original_remaining_after563={},active_tasks={},active_research_tasks={},active_agents_next_batch={},next_work=[],
        original_task_complete=True,whole_goal_complete=True,goal_complete=True,goal_status='complete',
        execution_status='original_task_complete',execution_paused=False,user_pause_request_active=False,
        all_research_agents_paused=False,all_running_computations_stopped=True,no_user_hard_blocker=True,
        last_accepted_progress='100.00',latest_progress_acceptance=ref(registration),last_progress_acceptance=ref(registration),
        latest_verified_progress_change=ref(registration),latest_C08_complete_acceptance=ref(dp),latest_stage_update_revision=624,
        checkpoint_revision=625,latest_live_checkpoint=ref(cf),preferred_resume_entry=str(cf),latest_algorithm_index=ref(np),
        latest_reading_guide=ref(guide),latest_user_readable_progress=ref(public),latest_research_revision=625,
        latest_published_research_directory=str(P),latest_published_research_revision=625,research_revision=625,
        latest_final_delivery_manifest=ref(mf),latest_final_delivery_freeze=ref(fr),current_unified_entry=str(P/'v1_entry.py'),
        current_status_authority='624 root original-task full acceptance +625 final recoverable publication; immutable earlier status is history',
        goal_manager_status_precision='task complete; exact manager result recorded separately after all final artifacts are published',
        historical_status_precedence='625/624 effective task state and r1 source-reader default supersede earlier status aliases; source/code/math/holds remain versioned',
        in_progress_candidate=None)
    for key in ['goal_tool_last_reported_status','goal_manager_last_observed_status']:
        v.pop(key,None)
    for key in ['latest_published_research_archive','latest_published_research_sha256','latest_published_research_verification',
                'latest_archive','archive_sha256','latest_formal_package']:
        v.pop(key,None)
    if 'modules'in v:
        for m in v['modules']:
            if m['id']=='C08':
                for key in ['base_verified_basis','remaining','latest_reading_vs_runtime','verification_status','latest_stage_acceptance']:
                    if key in m:m['historical_'+key+'_before624']=copy.deepcopy(m[key])
                m.update(stage='1.00',weighted_points='5.00',verification_status=decision['status'],unclosed_acceptance_items=[],
                    latest_stage_acceptance=str(dp),current_basis='624 root substantive acceptance after genuine runtime +R1 physical source/readable/IO/freeze +stable move; original done_when met',
                    base_verified_basis='原C08最后全链复现、边界/冲突/独立留出、资料/说明/IO完整取件、285永久件与稳定交付经真正非作者复核及624根实质验收；旧187/首版收件回执保历史。',
                    remaining='原C08支持范围无未闭必须交付。两历史导航快照等保存限制永久披露，未豁免任何核心资料。',
                    latest_reading_vs_runtime='同一稳定成品的有效r1资料入口与0.8原生运行；旧274保历史，当前285组合清单绑定。')
        assert sum(Decimal(m['weight'])*Decimal(m['stage']) for m in v['modules'])==Decimal('100.00')
    if type(v.get('history')) is list:
        v['history'].append(dict(revision=624,date=now,module='C08',old_stage='0.75',new_stage='1.00',old_score='98.75',score='100.00',progress_delta='1.25',reason=str(dp)))
    write(path,v)

source=read(W/'来源索引_current.json')
source.update(latest_current_research_checkpoint=ref(cf),latest_current_research_guide=ref(guide),latest_algorithm_index=ref(np),
    latest_original_C08_full_acceptance=ref(dp),current_final_delivery_directory=str(P),current_effective_source_reader=str(P/author['effective_reader']),
    current_final_delivery_manifest=ref(mf),original_task_delivery_complete=True,two_historical_navigation_snapshot_versions_unavailable=True)
write(W/'来源索引_current.json',source)
overview=R/'outputs/研究成果总览_先读这一份.txt'
s=overview.read_text()
s=s.replace('（最终整包验收前的审读稿，状态依据 rev623）','（最终交付版，状态依据 rev624／rev625）',1)
s=s.replace('目前验收进度为98.75%。原定范围内的单人整盘、约定五层时间变化和地区研究已经分别完成验收；最后1.25%是把全部成果统一交付，并完成整包的独立复核。','目前原任务验收进度为100%。原定范围内的单人整盘、约定五层时间变化、地区及原已批准语义规则完成验收；统一交付包也已通过独立运行、资料取件和最终完整性复核。',1)
s=s.replace('先看“当前研究与接续入口_rev623.txt”，再通过 rev623 算法导航查具体方法。','先看本机outputs/Part1_研究成果_统一可复现交付/00_0_当前有效入口_请先读_r1.txt，再通过rev625算法导航查具体方法。',1)
s=s.replace('后续成果由623增量接上。','后续研究由623增量接上，最终状态由624／625记录；原文中的较早进度为历史捕获。',1)
s=s.replace('新增20个统一运行与资料读取算法另有解释，它们不是20条新命理理论。最终成品会在总目录给出相对入口，照入口即可阅读或复现，不必翻聊天找规则。','当前20个统一运行与资料读取算法另有解释，其中18个原运输函数和2个r1当前取件定义；它们不是20条新命理理论。成品已给出相对阅读、取件与运行入口，不必翻聊天找规则。',1)
s=s.replace('将永久披露，不用新版冒充。','永久披露，不用新版冒充。',1)
s=s.replace('原典、规则、代码和必要输入输出实物的完整性，以最终独立复核逐项结论为准，不宣称全部历史每个字节都齐全。','已采用原典与规则依据、代码和必要输入输出实物已按最终独立复核逐项核取，不宣称全部历史每个字节都齐全。首版379条取件遗漏已补收和实测，未借历史导航限制豁免。另有一份早期被后次元数据编译覆盖的操作回执，不能凭旧文件名认证首次执行前时间戳，已附说明。',1)
s+='\n固定成品目录：'+str(P)+'\n最终验收与运行说明：'+str(public)+'\n研究过程、原始来源和失败／修正记录仍在项目work；整理后成果在outputs。保存的是成果与关键研究过程，不声称逐字另存全部聊天和工具输出。\n'
assert '目前验收进度为98.75%' not in s
overview.write_text(s)
sot=R/'SOURCE_OF_TRUTH.md'
s=sot.read_text()
old=next(l for l in s.splitlines()if l.startswith('先读['))
s=s.replace(old,'先读[研究成果总览](outputs/研究成果总览_先读这一份.txt)、[最终验收与使用说明624](outputs/Part1_研究成果_最终验收与使用说明_rev624.txt)、[625恢复入口](outputs/当前研究与接续入口_rev625.txt)。原任务100.00/100，原八模块均已按原范围验收。固定成品[有效R1入口](outputs/Part1_研究成果_统一可复现交付/00_0_当前有效入口_请先读_r1.txt)，[95方法4958精确导航](work/rev625_current_algorithm_navigation.json)。两历史导航旧字节未找回及早期操作回执精度限制永久披露；首版379资料遗漏已真正补收。100%指原任务交付验收，不是现实预测准确率。新增B/手环显示/物理呈现仍后置。',1)
sot.write_text(s)
sealed=seal_record_copies(W/'rev625_checkpoint_records',[cf,np,guide,registration,overview,public,evidence_index])
snapshot=W/'rev625_effective_current_state_snapshot'
snapshot.mkdir()
for name in current_names+['来源索引_current.json']:
    (snapshot/name).write_bytes((W/name).read_bytes())
(snapshot/'SOURCE_OF_TRUTH.md').write_bytes(sot.read_bytes())
snappins=seal_record_copies(W/'rev625_effective_current_state_snapshot_pins',list(snapshot.iterdir()))
write(W/'rev625_registration_receipt.json',dict(status='original_task_delivery_complete_all_artifacts_published',score='100.00',
    final_acceptance=ref(dp),checkpoint=ref(cf),navigation=ref(np),guide=ref(guide),overview=ref(overview),public=ref(public),
    frozen_checkpoint=sealed,current_state_snapshot=snappins,stable_delivery_directory=str(P),manifest=ref(mf),freeze=ref(fr),
    goal_manager_actual_completion_receipt_to_follow_after_all_files_complete=True))
assert ref(original)['sha256']==decision['original_ledger']['sha256']
print(json.dumps(dict(score='100.00',acceptance=ref(dp),checkpoint=ref(cf),overview=ref(overview),public=ref(public),stable_delivery_directory=str(P)),ensure_ascii=False,indent=2))
