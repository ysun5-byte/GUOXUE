from pathlib import Path
from hashlib import sha256
import json,zipfile,time,collections
D=Path(__file__).resolve().parent;O=Path(json.loads((D/'candidate_location.json').read_text())['path']);Q=json.loads((O/'research_catalog_effective_r1.json').read_text());E=json.loads((O/'all95_normalized_original_manifest_rows_effective_r1.json').read_text());refs=E['expected_all_payload_path_records'];byhash={};aliases=collections.defaultdict(list)
for x in refs:
 h=x['sha256'];aliases[h].append((x['component'],x['relative']));meta=Q['objects'][h];assert meta['bytes']==x['bytes'];key=str((Path(x['manifest']).parent/x['relative']).relative_to(D.parents[1]));assert Q['files'][key]['sha256']==h;byhash[h]=meta
assert len(E['rows'])==95 and all(x['normalized_payload_rows']>0 for x in E['rows']);zips={};rows=[];start=time.time();nbytes=0
for i,(h,obj)in enumerate(sorted(byhash.items())):
 v=obj['volume_relative_path']
 if v not in zips:zips[v]=zipfile.ZipFile(O/v)
 info=zips[v].getinfo(obj['member']);assert not info.is_dir();d=sha256();n=0
 with zips[v].open(info)as stream:
  for b in iter(lambda:stream.read(1024*1024),b''):d.update(b);n+=len(b)
 assert(n,d.hexdigest())==(obj['bytes'],h),(v,obj['member']);nbytes+=n;rows.append(dict(sha256=h,bytes=n,path_reference_count=len(aliases[h]),all_expected_paths=aliases[h],volume=v,member=obj['member']))
 if(i+1)%3000==0:print('readSHA95 uniqueobjects',i+1,'/',len(byhash),flush=True)
for z in zips.values():z.close()
r=dict(all_passed=True,methods95=95,all_manifest_path_records49419=len(refs),all_unique_objects_actual_full_read_SHA=True,unique_objects=len(rows),unique_read_bytes=nbytes,all_shared_SHA_multiple_paths_preserved=True,nonempty_supported_schemas_only=True,old_source_code_native_entry_guard_unchanged=True,source_objects=rows,elapsed_seconds=time.time()-start,no_native_or_math_calls=True);(D/'actual_all95_r1_full_object_SHA_and_alias_validation.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');print('all95 r1 fully readSHA',len(rows),nbytes)
