from pathlib import Path
from hashlib import sha256
import json,gzip,sys,runpy,subprocess
D=Path(__file__).resolve().parent;O=Path(json.loads((D/'candidate_location.json').read_text())['path']);A=D/'actual_effective_r1_reader_IO';A.mkdir(exist_ok=True)
if len(sys.argv)==1:
 E=json.loads((O/'all95_normalized_original_manifest_rows_effective_r1.json').read_text());chosen=[E['already_in_original266_records244'][1],E['restored_from_actual_rev359_records135'][0]];rows=[]
 for i,x in enumerate(chosen):
  key=str((Path(x['manifest']).parent/x['relative']).relative_to(D.parents[1]));p=subprocess.run([sys.executable,'-I','-B',__file__,str(i),key],capture_output=True,timeout=300);assert p.returncode==0,(key,p.stderr[-1000:]);assert(len(p.stdout),sha256(p.stdout).hexdigest())==(x['bytes'],x['sha256']);(A/(str(i)+'.stdout.gz')).write_bytes(gzip.compress(p.stdout,mtime=0));(A/(str(i)+'.stderr')).write_bytes(p.stderr);rows.append(dict(key=key,bytes=len(p.stdout),sha256=x['sha256'],actual_public_main_and_fetch=True))
 Q=json.loads((O/'research_catalog_effective_r1.json').read_text())
 for i,key in enumerate(Q['unavailable_historical_SHA_keys']):
  p=subprocess.run([sys.executable,'-I','-B',str(O/'research_files_effective_r1.py'),'show',key],capture_output=True,timeout=300);assert p.returncode and not p.stdout and b'historical_navigation_snapshot_bytes_unavailable'in p.stderr;(A/('unavailable'+str(i)+'.stderr')).write_bytes(p.stderr);rows.append(dict(key=key,explicit_unavailable_no_placeholder=True))
 merged={}
 for p in sorted(A.glob('*.function_IO.json.gz')):
  for k,v in json.loads(gzip.decompress(p.read_bytes())).items():merged.setdefault(k,v)
 assert len(merged)==2,merged.keys();(A/'first_complete_actual_r1_reader_IO.json.gz').write_bytes(gzip.compress(json.dumps(merged,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode(),mtime=0));(A/'complete_report.json').write_text(json.dumps(dict(all_passed=True,rows=rows,actual_r1_named_definitions2=True,full_original_args_and_return_bytes_not_summaries=True,old18_transport_source_and_IO_unchanged=True,no_native_or_math=True),ensure_ascii=False,indent=2)+'\n');print('r1 reader2 complete actual typedIO and known/missing CLI passed');raise SystemExit(0)
case,key=sys.argv[1:];records={};active={};source=O/'research_files_effective_r1.py'
def typed(v):
 if type(v)is bytes:return dict(python_type='bytes',hex=v.hex(),bytes=len(v),sha256=sha256(v).hexdigest())
 return v
def profile(frame,event,arg):
 if frame.f_code.co_filename!=str(source)or frame.f_code.co_name not in {'fetch','main'}:return
 name=frame.f_code.co_name
 if name in records:return
 if event=='call':active[id(frame)]=dict(input={k:typed(frame.f_locals[k])for k in frame.f_code.co_varnames[:frame.f_code.co_argcount]},module_source_sha256=sha256(source.read_bytes()).hexdigest(),source_file=source.name,line=frame.f_code.co_firstlineno)
 elif event=='return'and id(frame)in active:row=active.pop(id(frame));row['return_event_value']=typed(arg);records[name]=row
sys.argv=[str(source),'show',key];sys.setprofile(profile)
try:runpy.run_path(str(source),run_name='__main__')
except SystemExit as e:assert e.code==0
finally:sys.setprofile(None);(A/(case+'.function_IO.json.gz')).write_bytes(gzip.compress(json.dumps(records,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode(),mtime=0))
