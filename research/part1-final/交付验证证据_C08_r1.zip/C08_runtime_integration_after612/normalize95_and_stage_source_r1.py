# -*- coding: utf-8 -*-
from pathlib import Path
from hashlib import sha256
import json,re,zipfile,collections
D=Path(__file__).resolve().parent;R=D.parents[1];O=Path(json.loads((D/'candidate_location.json').read_text())['path']);S=D/'r1_stage';S.mkdir();N=json.loads((R/'work/rev623_current_algorithm_navigation.json').read_text());Q=json.loads((O/'research_catalog.json').read_text());expected=json.loads((R/'work/C08_genuine_independent_review449/actual/final95_normalized_manifest_payload_availability.json').read_text());expected={x['component']:x for x in expected['rows']};universe=dict(Q['objects']);oldarchive='volumes/Part1_整盘取用与算法解释_研究增量_rev266.zip'
with zipfile.ZipFile(O/oldarchive)as z:
 prefix='Part1_整盘取用与算法解释_研究增量_rev266/';mf=json.loads(z.read(prefix+'交付SHA256清单.json'))
 for k,v in mf.items():universe.setdefault(v['sha256'],dict(bytes=v['bytes'],volume_relative_path=oldarchive,member=prefix+k))
def normalize(source):
 v=json.loads(source.read_text());v=v['files']if isinstance(v,dict)and'files'in v else v
 if type(v)is dict:items=list(v.items())
 elif type(v)is list:
  items=[]
  for i,row in enumerate(v):
   if type(row)is not dict:raise ValueError('manifest_list_record_dict_required:'+str(source)+':'+str(i))
   names=[row[k]for k in ['path','relative_path','file']if isinstance(row.get(k),str)]
   if len(set(names))!=1:raise ValueError('unambiguous_manifest_record_path_required:'+str(source)+':'+str(i))
   items.append((names[0],row))
 else:raise ValueError('known_actual_manifest_container_required:'+str(source))
 if not items:raise ValueError('nonempty_supported_manifest_payload_required:'+str(source))
 result=[];seen=set()
 for rel,meta in items:
  if type(rel)is not str or Path(rel).is_absolute()or'..'in Path(rel).parts or rel in seen:raise ValueError('unique_relative_manifest_path_required:'+str(source)+':'+str(rel))
  seen.add(rel)
  if type(meta)is str:h=meta;n=None;schema='SHAonly'
  elif type(meta)is dict:
   h=meta.get('sha256');sizes=[meta[k]for k in ['bytes','size']if k in meta]
   if not sizes or any(type(x)is not int or x<0 for x in sizes)or len(set(sizes))!=1:raise ValueError('actual_bytes_or_size_manifest_required:'+str(source)+':'+rel)
   n=sizes[0];schema='bytes'if'bytes'in meta else'size'
  else:raise ValueError('known_manifest_pin_schema_required:'+str(source)+':'+rel)
  if type(h)is not str or re.fullmatch('[0-9a-f]{64}',h)is None:raise ValueError('exact_SHA256_required:'+str(source)+':'+rel)
  result.append(dict(relative=rel,sha256=h,declared_bytes=n,value_schema=schema))
 return result
rows=[];missing=[];new={};old244=[];allrefs=[]
for m in N['methods']:
 P=Path(m['workspace_path']);candidates=[P/n for n in ['manifest.json','RESEARCH_MANIFEST.json','DELIVERY_MANIFEST.json','release_manifest.json']if(P/n).is_file()]
 if len(candidates)!=1:raise ValueError('one_exact_original_manifest_required:'+m['component'])
 mp=candidates[0];refs=normalize(mp);ind=expected[m['component']]
 if'independent_normalized_rows'in ind:assert len(refs)==ind['independent_normalized_rows']
 if'normalized_payload_rows'in ind:assert len(refs)==ind['normalized_payload_rows'],(m['component'],len(refs),ind['normalized_payload_rows'])
 for ref in refs:
  h=ref['sha256'];p=P/ref['relative'];obj=universe.get(h)
  if obj is None:
   raw=p.read_bytes();actual=dict(bytes=len(raw),sha256=sha256(raw).hexdigest());assert actual['sha256']==h,(m['component'],ref['relative'],'actual source SHA mismatch')
   if ref['declared_bytes']is not None:assert ref['declared_bytes']==len(raw)
   new.setdefault(h,dict(path=str(p),**actual));obj=dict(bytes=len(raw),volume_relative_path='volumes/research_missing_original_manifest_payloads_r1.zip',member='sha256/'+h);universe[h]=obj
  if ref['declared_bytes']is not None:assert obj['bytes']==ref['declared_bytes'],(m['component'],ref['relative'],'size mismatch')
  record=dict(component=m['component'],manifest=str(mp),relative=ref['relative'],bytes=obj['bytes'],sha256=h,value_schema=ref['value_schema'],storage=obj);allrefs.append(record)
  if h not in Q['objects']:
   missing.append(record)
   if obj['volume_relative_path']==oldarchive:old244.append(record)
  Q['objects'][h]=obj
  key=str(p.resolve().relative_to(R));meta=dict(bytes=obj['bytes'],sha256=h,meaning='all95 exact original manifest r1 normalized payload; preserved path and SHA even if shared content')
  if key in Q['files']and Q['files'][key]['sha256']!=h:raise ValueError('explicit_reference_version_resolution_required_for_same_source_path:'+key)
  Q['files'].setdefault(key,meta);Q['files'].setdefault('sha256:'+h,dict(meta,meaning='immutable exact version alias'));Q['original_source_path_to_relative_key'][str(p.resolve())]=key
 rows.append(dict(component=m['component'],manifest_filename=mp.name,manifest_pin=dict(bytes=mp.stat().st_size,sha256=sha256(mp.read_bytes()).hexdigest()),normalized_payload_rows=len(refs),manifest_value_schemas=dict(collections.Counter(x['value_schema']for x in refs)),every_original_expected_path_preserved=True))
# Missing set is against the frozen first catalog, preserving duplicate path references rather than mutating the comparison while traversing.
oldQ=json.loads((O/'research_catalog.json').read_text());missing=[r for r in allrefs if r['sha256']not in oldQ['objects']];old244=[r for r in missing if r['storage']['volume_relative_path']==oldarchive];remaining=[r for r in missing if r['storage']['volume_relative_path']!=oldarchive];assert(len(missing),len(old244),len(remaining))==(379,244,135),(len(missing),len(old244),len(remaining))
V=S/'volumes/research_missing_original_manifest_payloads_r1.zip';V.parent.mkdir()
with zipfile.ZipFile(V,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=3,allowZip64=True)as z:
 for h,v in sorted(new.items()):
  raw=Path(v['path']).read_bytes();assert(len(raw),sha256(raw).hexdigest())==(v['bytes'],h);z.writestr('sha256/'+h,raw)
Q['source_manifest_schemas_effective_r1']=dict(supported_value_schemas=['dict bytes+sha256','dict size+sha256','SHA256 string only with actual verified source/archive size'],supported_containers=['files mapping','direct mapping','files list with explicit relative path'],unknown_or_empty_schema_hard_error=True,manifest_filenames=['manifest.json','RESEARCH_MANIFEST.json','DELIVERY_MANIFEST.json','release_manifest.json'],all95_nonempty_normalized=True,first_report_with_zero_rows_superseded_not_complete=True)
Q['source_manifest_all95_effective_r1']=rows;Q['initial_source_catalog_and_reader_historical_only']=True;Q['current_effective_source_reader']='research_files_effective_r1.py';Q['all_current_accepted_payloads_in_relative_volumes']=True
(S/'research_catalog_effective_r1.json').write_text(json.dumps(Q,ensure_ascii=False,sort_keys=True,separators=(',',':'))+'\n');(S/'all95_normalized_original_manifest_rows_effective_r1.json').write_text(json.dumps(dict(schema='C08-all95-source-manifests-effective-normalization-r1/1',all_passed=True,rows=rows,expected_all_payload_path_records=allrefs,source_path_record_count=len(allrefs),same_SHA_multiple_paths_preserved=True,normalized_nonempty_methods95=len(rows),missing_from_first_catalog_records379=missing,already_in_original266_records244=old244,restored_from_actual_rev359_records135=remaining,new_unique_objects=len(new),new_unique_uncompressed_bytes=sum(v['bytes']for v in new.values()),all_current_native_entry_guard_rule_sources_unchanged=True,no_BaZi_or_large_parameter_math=True),ensure_ascii=False,indent=2)+'\n')
# The two production reader definitions differ only in the fixed catalog filename literals; no path guard/IO/type operations change.
s=(O/'research_files.py').read_text().replace("CATALOG_SHA='"+sha256((O/'research_catalog.json').read_bytes()).hexdigest()+"'","CATALOG_SHA='"+sha256((S/'research_catalog_effective_r1.json').read_bytes()).hexdigest()+"'").replace("ROOT/'research_catalog.json'","ROOT/'research_catalog_effective_r1.json'");(S/'research_files_effective_r1.py').write_text(s)
rep=dict(all_passed=True,methods95=len(rows),all_expected_path_records=len(allrefs),schema_counts=dict(collections.Counter(r['value_schema']for r in allrefs)),first_missing379=len(missing),old266_exact_locators244=len(old244),actual_source_restored135=len(remaining),new_unique_objects=len(new),new_unique_bytes=sum(v['bytes']for v in new.values()),new_volume=dict(bytes=V.stat().st_size,sha256=sha256(V.read_bytes()).hexdigest()),same_SHA_alias_path_records_preserved=True,original274_not_modified=True,no_math=True);(D/'r1_stage_normalization_completion.json').write_text(json.dumps(rep,ensure_ascii=False,indent=2)+'\n');print(json.dumps(rep,ensure_ascii=False))
