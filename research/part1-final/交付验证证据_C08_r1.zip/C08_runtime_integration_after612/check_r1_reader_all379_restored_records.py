from pathlib import Path
from hashlib import sha256
import json,types,time
D=Path(__file__).resolve().parent;O=Path(json.loads((D/'candidate_location.json').read_text())['path']);Q=json.loads((O/'research_catalog_effective_r1.json').read_text());E=json.loads((O/'all95_normalized_original_manifest_rows_effective_r1.json').read_text());T=types.ModuleType('reader_r1');T.__file__=str(O/'research_files_effective_r1.py');exec(compile((O/'research_files_effective_r1.py').read_bytes(),T.__file__,'exec'),T.__dict__);rows=[];start=time.time()
for i,x in enumerate(E['missing_from_first_catalog_records379']):
 key=str((Path(x['manifest']).parent/x['relative']).relative_to(D.parents[1]));raw=T.fetch(key);assert(len(raw),sha256(raw).hexdigest())==(x['bytes'],x['sha256']);rows.append(dict(key=key,bytes=len(raw),sha256=x['sha256'],returned_full_actual_bytes=True,original_source_root='old266 complete volume'if x['storage']['volume_relative_path'].endswith('rev266.zip')else'restored rev359 original bytes'))
 if(i+1)%50==0:print('r1 realreader restored fullrecords',i+1,'/379',flush=True)
for key in Q['unavailable_historical_SHA_keys']:
 try:T.fetch(key)
 except ValueError as err:assert 'historical_navigation_snapshot_bytes_unavailable'in str(err)
 else:raise AssertionError('no historical placeholder')
r=dict(all_passed=True,actual_production_fetch_calls379=len(rows),old266_locator_records244=sum(x['original_source_root'].startswith('old266')for x in rows),restored_rev359_records135=sum(x['original_source_root'].startswith('restored')for x in rows),rows=rows,two_historical_navigation_SHA_requests_explicit_unavailable=True,source_reader_scope_only_no_native_or_math_calls=True,elapsed_seconds=time.time()-start);(D/'actual_r1_reader_all379_restored_records.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');print('379 reader actual fullbytes +2 unavailable allpassed')
